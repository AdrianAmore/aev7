﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace aev7
{
    public partial class FrmMantenimiento : Form
    {
        public FrmMantenimiento()
        {
            InitializeComponent();
        }

        private void btnVolver_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FrmMantenimiento_Load(object sender, EventArgs e)
        {
            CargaListaEmpleados();
            CargaListaFichajes();
        }

        private void CargaListaEmpleados()
        {
            string seleccion = "Select * from empleados";
            if (ConexionBD.Conexion != null)
            {
                ConexionBD.AbrirConexion();
                dtgvEmpleados.DataSource = Empleado.BuscarEmpleado(seleccion);
                ConexionBD.CerrarConexion();
            }
            else
            {
                MessageBox.Show("No existe conexión a la Base de datos");
            }
        }

        private void CargaListaFichajes()
        {
            string seleccion = "Select * from fichaje";
            if (ConexionBD.Conexion != null)
            {
                ConexionBD.AbrirConexion();
                dtgvFichajes.DataSource = Fichaje.BuscarFichaje(seleccion);
                ConexionBD.CerrarConexion();
            }
            else
            {
                MessageBox.Show("No existe conexión a la Base de datos");
            }
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            int resultado = 0;
            try
            {
                if (ConexionBD.Conexion != null)
                {
                    ConexionBD.AbrirConexion();
                    Empleado emp = new Empleado();
                    emp.Dni = txtNifMantenimiento.Text;
                    emp.Nombre = txtNombre.Text;
                    emp.Apellido = txtApellidos.Text;
                    if (chkAdmin.Checked)
                    {
                        emp.Admin = 1;
                        emp.Password = txtContra.Text;
                    }
                    else
                    {
                        emp.Admin = 0;
                        emp.Password = null;
                    }
                    List<Empleado> empl = new List<Empleado>();
                    empl = Empleado.BuscarEmpleado(string.Format("SELECT * FROM empleados WHERE dni LIKE '{0}'", txtNifMantenimiento.Text)); //Comprueba que no existe ningun empleado con ese dni
                    if (empl.Count == 0)
                    {
                        resultado = emp.AgregarEmpleado(emp);
                    }
                    else
                    {
                        MessageBox.Show("El dni introducido ya esta registrado");
                    }
                    if (resultado > 0)
                    {
                        txtApellidos.Clear();
                        txtContra.Clear();
                        txtNifMantenimiento.Clear();
                        txtNombre.Clear();
                        txtNifMantenimiento.Focus();
                    }
                    ConexionBD.CerrarConexion();
                    CargaListaEmpleados();
                }
                else
                {
                    MessageBox.Show("No se ha podido abrir la conexión con la Base de Datos");
                    ConexionBD.CerrarConexion();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + "\n" + ex.StackTrace);
                ConexionBD.CerrarConexion();
            }
            finally  // en cualquier caso cierro la conexión (haya error o no)
            {
                ConexionBD.CerrarConexion();
            }
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            this.Close();
            this.Dispose();
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            try
            {
                int resultado;

                if (dtgvEmpleados.SelectedRows.Count == 1) // Si hay una fila seleccionada en el datagridview
                {
                    string dniEmpleado = (string)dtgvEmpleados.CurrentRow.Cells[0].Value; // Obtenemos el dni de la fila seleccionada

                    DialogResult confirmacion = MessageBox.Show("Borrado de registro seleccionado. ¿Continuar?",
                                                "Eliminación", MessageBoxButtons.YesNo);

                    if (confirmacion == DialogResult.Yes)
                    {
                        if (ConexionBD.Conexion != null)
                        {
                            ConexionBD.AbrirConexion();
                            resultado = Empleado.EliminarEmpleado(dniEmpleado);
                            Fichaje.EliminarFichaje(dniEmpleado);
                        }
                        else
                        {
                            MessageBox.Show("No se ha podido abrir la conexión con la Base de Datos");
                        }
                        // Cierro la conexión
                        ConexionBD.CerrarConexion();
                        // volvemos a cargar toda la lista de usuarios;
                        CargaListaEmpleados();
                        CargaListaFichajes();
                    }
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
