﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace aev7
{
    public partial class FrmPrincipal : Form
    {
        public FrmPrincipal()
        {
            InitializeComponent();


        }

        private void tmrReloj_Tick(object sender, EventArgs e)
        {
            lblReloj.Text = DateTime.Now.ToLongTimeString();
        }

        private void FrmPrincipal_Load(object sender, EventArgs e)
        {
            lblFecha.Text = DateTime.Today.ToString("dd/MM/yyyy");
        }


        private void btnMantenimiento_Click(object sender, EventArgs e)
        {
            if (txtDni.Text != "")
            {


                if (Empleado.ValidaNIF(txtDni.Text)) //Comprueba si el NIF es correcto.
                {
                    try
                    {
                        if (ConexionBD.Conexion != null)
                        {
                            ConexionBD.AbrirConexion(); //Abre la conexión
                            string consulta = string.Format("SELECT * FROM empleados WHERE dni LIKE '{0}'", txtDni.Text); //Consulta por alguien con el NIF introducido
                            List<Empleado> admin = Empleado.BuscarEmpleado(consulta);
                            if (admin != null) //Al devolver una lista comprueba que esta no está vacía
                            {
                                if (admin[0].Admin) //Comprueba si el usuario es admin
                                {
                                    string pwd = Interaction.InputBox("Introduce la contraseña de administración:", "Contraseña administración"); //Muestra un inputbox para la contraseña

                                    if (pwd == admin[0].Password) // Si la contaseña coincide se abre el formulario de mantenimiento
                                    {
                                        ConexionBD.CerrarConexion();
                                        FrmMantenimiento frmMantenimiento = new FrmMantenimiento();
                                        frmMantenimiento.ShowDialog(); // Muestra el frmMantenimiento
                                    }
                                    else if (pwd == "")
                                    {
                                        MessageBox.Show("Volviendo");
                                    }
                                    else
                                    {
                                        MessageBox.Show("La contraseña es incorrecta");
                                    }
                                }
                                else
                                {
                                    MessageBox.Show("Este usuario no es admin."); //Si no lo es se avisa de ello
                                    ConexionBD.CerrarConexion();
                                }
                            }
                            else
                            {
                                MessageBox.Show("El usuario no existe en la base de datos"); //Si la lista está vacía el usuario no existe en la bd y se avisa de ello.
                                ConexionBD.CerrarConexion();
                            }

                        }
                    }
                    catch (Exception ex)
                    {

                        MessageBox.Show(ex.Message + "\n" + ex.StackTrace); //Muestra el mensaje de error.
                    }
                    finally
                    {
                        ConexionBD.CerrarConexion(); //Pase lo que pase cierra la conexión
                    }
                }
                else
                {
                    MessageBox.Show("El NIF no es correcto, la letra no se corresponde"); //Si el NIF no es correcto muestra un mensaje.
                }
            }
            else
            {
                MessageBox.Show("Introduce un NIF");
            }
        }
    }
}
