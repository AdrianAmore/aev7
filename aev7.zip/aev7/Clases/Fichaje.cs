﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace aev7
{
    class Fichaje
    {
        private string dni;
        private DateTime dia;
        private DateTime horaEntrada;
        private DateTime horaSalida;
        private bool enCurso; //Si está dentro de la empresa o no;

        //Propiedades
        public string Dni { get { return dni; } set { dni = value; } }
        public DateTime Dia { get { return dia; } set { dia = value; } }
        public DateTime HoraEntrada { get { return horaEntrada; } set { horaEntrada = value; } }
        public DateTime HoraSalida { get { return horaSalida; } set { horaSalida = value; } }
        public bool EnCurso { get { return enCurso; } set { enCurso = value; } }

        //Constructor
        public Fichaje(string dni, DateTime dia, DateTime hE, DateTime hS, bool enC)
        {
            this.dni = dni;
            this.dia = dia;
            this.horaEntrada = hE;
            this.horaSalida = hS;
            this.enCurso = enC;
        }
        public static List<Fichaje> BuscarFichaje(string consulta)
        {
            List<Fichaje> lista = new List<Fichaje>();
            MySqlCommand comando = new MySqlCommand(consulta, ConexionBD.Conexion);
            MySqlDataReader reader = comando.ExecuteReader();
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    Fichaje fich = new Fichaje(reader.GetString(0), reader.GetDateTime(1), reader.GetDateTime(2), 
                        reader.GetDateTime(3), reader.GetBoolean(4));
                    lista.Add(fich);
                }
                reader.Close();
            }
            return lista;
        }

    }
}
