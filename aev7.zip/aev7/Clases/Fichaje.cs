﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace aev7
{
    class Fichaje
    {
        private string dni;
        private DateTime dia;
        private string horaEntrada;
        private string horaSalida;
        private int enCurso; //Si está dentro de la empresa o no;

        //Propiedades
        public string Dni { get { return dni; } set { dni = value; } }
        public DateTime Dia { get { return dia; } set { dia = value; } }
        public string HoraEntrada { get { return horaEntrada; } set { horaEntrada = value; } }
        public string HoraSalida { get { return horaSalida; } set { horaSalida = value; } }
        public int EnCurso { get { return enCurso; } set { enCurso = value; } }

        //Constructor
        public Fichaje(string dni, DateTime d, string hE, string hS, int enC)
        {
            this.dni = dni;
            this.dia = d;
            this.horaEntrada = hE;
            this.horaSalida = hS;
            this.enCurso = enC;
        }

        public Fichaje()
        {

        }

        public static List<Fichaje> BuscarFichaje(string consulta)
        {
            List<Fichaje> lista = new List<Fichaje>();
            MySqlCommand comando = new MySqlCommand(consulta, ConexionBD.Conexion);
            MySqlDataReader reader = comando.ExecuteReader();
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    Fichaje fich = new Fichaje(reader.GetString(1), reader.GetDateTime(2), reader.GetString(3),
                        reader.GetString(4), reader.GetInt32(5));
                    lista.Add(fich);
                }
                reader.Close();
            }
            return lista;
        }


        public int AgregarFichaje(Fichaje fich)
        {
            int retorno;
            string consulta = String.Format("INSERT INTO fichaje (dni,fecha,entrada,salida,enCurso) VALUES " +
                "('{0}','{1}','{2}','{3}','{4}')", fich.dni, fich.dia.ToString("yyyy/MM/dd"), fich.horaEntrada, fich.horaSalida, fich.enCurso);

            MySqlCommand comando = new MySqlCommand(consulta, ConexionBD.Conexion);

            retorno = comando.ExecuteNonQuery();

            return retorno;
        }

        public static int SalidaFichaje(string hora, int enC, string dniB)
        {
            int retorno;
            string consulta = String.Format("UPDATE fichaje SET salida='{0}', enCurso={1} WHERE dni LIKE '{2}' ORDER BY idFichaje DESC LIMIT 1",hora,enC,dniB);

            MySqlCommand comando = new MySqlCommand(consulta, ConexionBD.Conexion);

            retorno = comando.ExecuteNonQuery();

            return retorno;

        }

        public static int EliminarFichaje(string identidad)
        {
            int retorno;
            string consulta = string.Format("DELETE FROM fichaje WHERE dni='{0}'", identidad);
            MySqlCommand comando = new MySqlCommand(consulta, ConexionBD.Conexion);
            retorno = comando.ExecuteNonQuery();
            return retorno;
        }
    }
}
