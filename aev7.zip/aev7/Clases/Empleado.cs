﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace aev7
{
    class Empleado
    {
        private string dni;
        private string nombre;
        private string apellido;
        private bool admin;
        private string password;

        //Propiedades
        public string Dni { get { return dni; } set { dni = value; } }
        public string Nombre { get { return nombre; } set { nombre = value; } }
        public string Apellido { get { return apellido; } set { apellido = value; } }
        public bool Admin { get { return admin; } set { admin = value; } }
        public string Password { get { return password; } set { password = value; } }

        //Constructor
        public Empleado(string dni, string nom, string ape, bool adm, string pass)
        {
            this.dni = dni;
            this.nombre = nom;
            this.apellido = ape;
            this.admin = adm;
            this.password = pass;
        }

        public Empleado()
        {

        }

        static public bool ValidaNIF(string nif) //Función para validar que el DNI tiene la letra que le corresponde.
        {
            bool valido = false;
            const int b = 23;
            string dniSinLetra = nif.Remove(nif.Length - 1, 1); //Elimina la letra del nif
            int a = int.Parse(dniSinLetra); //Convierte el string a int
            int x = a / b;
            int z = x * b;
            int resto = a - z;
            string[] letras = new string[23] { "T", "R", "W", "A", "G", "M", "Y", "F", "P", "D",
                                                "X", "B", "N", "J", "Z","S","Q","V","H","L","C","K","E"};
            string nifAComprobar = dniSinLetra.ToString() + letras[resto]; //Crea lo que sería  tu nif con la letra correcta
            if (nifAComprobar == nif) //Si tu nif es igual al que se genera como correcto retorna true
            {
                valido = true;
                return valido;
            }
            else
            {
                return valido;
            }
        }

        public static List<Empleado> BuscarEmpleado(string consulta)
        {
            List<Empleado> lista = new List<Empleado>();
            // MessageBox.Show(consulta);   -Se puede activar esta línea para testear la sintaxis de la consulta.

            // Creamos el objeto command al cual le pasamos la consulta y la conexión
            MySqlCommand comando = new MySqlCommand(consulta, ConexionBD.Conexion);
            // Ejecutamos el comando y recibimos en un objeto DataReader la lista de registros seleccionados.
            // Recordemos que un objeto DataReader es una especie de tabla de datos virtual.
            MySqlDataReader reader = comando.ExecuteReader();

            if (reader.HasRows)   // En caso que se hayan registros en el objeto reader
            {
                // Recorremos el reader (registro por registro) y cargamos la lista de usuarios.
                while (reader.Read())
                {
                    Empleado user = new Empleado(reader.GetString(0),reader.GetString(1),reader.GetString(2),
                        reader.GetBoolean(3),reader.GetString(4));
                    lista.Add(user);
                }
                reader.Close();
            }
            // devolvemos la lista cargada con los usuarios.
            return lista;

        }

        public int AgregarEmpleado(Empleado usu)
        {
            int retorno;
            string consulta = String.Format("INSERT INTO empleados (dni,nombre,apellidos,admin,contraseña) VALUES " +
                "('{0}','{1}','{2}','{3}','{4}')", usu.dni, usu.nombre, usu.apellido, usu.admin, usu.password);

            MySqlCommand comando = new MySqlCommand(consulta, ConexionBD.Conexion);

            retorno = comando.ExecuteNonQuery();

            return retorno;
        }
    }
}
